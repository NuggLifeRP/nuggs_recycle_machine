fx_version 'cerulean'
game { 'gta5' }
author 'NuggAssassin'
description 'Recycle Machine Locations'
version '2.0.0'


data_file 'DLC_ITYP_REQUEST' 'stream/recycle_machine.ytyp'


